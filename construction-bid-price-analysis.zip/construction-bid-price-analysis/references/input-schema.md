# Normalized bid data

Use this structure for intermediate JSON and for the workbook's source tables. Keep source values unchanged; add reviewed/corrected fields rather than overwriting them.

## Project object

Required when known:

- `name`, `tender_no`, `region`, `pricing_date`, `currency`
- `tax_mode`: for example `含税`, `不含税`, or `未知`
- `control_total` and `control_type`: tender control price, owner estimate, engineer estimate or other named basis
- `thresholds`: project-specific review triggers; omit to use helper defaults and disclose them

## Bidder object

- `bidder_id`: stable unique identifier
- `name`: exact bidder name from the source
- `stated_total`: bidder's signed/stated total
- `source_file`, `source_pages`
- `notes`: exclusions, alternatives, discounts, tax or scope statements

## Item object

- `item_key`: BOQ item code preferred; otherwise a reviewed composite key
- `code`, `name`, `spec`, `unit`, `scope_note`
- `tender_quantity`
- `control_unit_price`, `control_line_total`
- `market_low`, `market_high`, `market_basis`
- `change_likelihood`: optional reviewed value from 0 to 1; never infer it from price alone
- `payment_stage`: optional, used only for front-loading analysis
- `bids`: one record per bidder, containing:
  - `bidder_id`
  - `quoted_quantity`, `unit_price`, `line_total`
  - optional `material_unit_price`, `labor_unit_price`, `machinery_unit_price`, `other_unit_price`
  - `source_file`, `source_page`, `source_row`
  - `extraction_confidence`: `high`, `medium`, or `low`
  - `review_status`, `review_note`

## Matching rules

1. Match exact BOQ codes first.
2. If codes are absent, require compatible name, specification, unit and scope.
3. Keep alternatives and exclusions separate.
4. Never use fuzzy text similarity as the only reason to merge materially different rows.
5. Create an explicit mapping table with `source_item`, `mapped_item_key`, `method`, `confidence` and `review_status`.

## Example

```json
{
  "project": {
    "name": "示例项目",
    "currency": "CNY",
    "tax_mode": "含税",
    "control_total": 350000
  },
  "bidders": [
    {"bidder_id": "A", "name": "投标人A", "stated_total": 328783}
  ],
  "items": [
    {
      "item_key": "001",
      "name": "镀锌管",
      "spec": "Q235A DN80",
      "unit": "m",
      "tender_quantity": 100,
      "control_unit_price": 150,
      "market_low": 135,
      "market_high": 155,
      "bids": [
        {
          "bidder_id": "A",
          "quoted_quantity": 100,
          "unit_price": 165,
          "line_total": 16500,
          "source_page": 6,
          "extraction_confidence": "high"
        }
      ]
    }
  ]
}
```
