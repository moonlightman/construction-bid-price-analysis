# Market price verification

## Search plan

Search using the combination most likely to make the result comparable:

`region + pricing month + item name + specification/grade + unit + tax/freight/install basis`

Use the available internet-search skill or browser. Prefer current primary sources and open the source page rather than relying on a search snippet.

## Source preference

1. Provincial/municipal engineering cost information, official material price bulletins and competent authorities.
2. Public procurement or tender award results with a matching specification and date.
3. Manufacturer or authorized distributor quotations and price notices.
4. Recognized commodity or construction-cost indices for time adjustment.
5. Reputable industry platforms.
6. Retail/e-commerce listings only as low-weight context when scope and channel are comparable.

## Comparability adjustments

Keep the original published value and show every adjustment separately:

- unit conversion;
- tax addition/removal;
- freight to project location;
- installation/labor inclusion or exclusion;
- index-based time adjustment;
- grade, thickness, diameter, pressure class, brand or quality adjustment.

Do not use a conversion that lacks a defensible physical or contractual basis. If the source does not disclose tax, freight or scope, mark it `未知`.

## Evidence table

For each source capture:

- item key and compared bidder item;
- publisher and source title;
- URL;
- publication/effective date and access date;
- region and market channel;
- exact specification and unit;
- original price/range;
- tax, freight and installation basis;
- conversion formula and adjusted comparable range;
- reliability tier and limitation.

Use two independent sources for high-impact market conclusions where practicable. A reseller copying another publisher is not independent evidence.

## Wording

Use `高于可比市场区间`, `低于可比市场区间`, `位于可比市场区间` or `证据不足`. Do not call a price unreasonable when the specification, date or scope is not comparable.
