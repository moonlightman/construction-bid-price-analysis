# Price analysis methodology

## Benchmark hierarchy

Use each benchmark separately and label it. Do not blend them into one unexplained reference price.

1. Tender control/BOQ price, when its date, tax and scope are comparable.
2. Adjusted external market range.
3. Peer median for the same reviewed item.
4. Peer mean as a descriptive measure; it is more sensitive to outliers.

For a candidate unbalanced-price calculation, use the first available comparable benchmark in that order and record `reference_type`.

## Default review triggers

These are initial screening defaults, not universal industry rules. Put them in the workbook assumptions area and let the reviewer edit them.

- Unit-price deviation from control or peer median: `±15%`
- Severe unit-price deviation: `±30%`
- Material line-item impact: absolute difference from reference ≥ `1%` of bidder total
- High impact: absolute difference from reference ≥ `3%` of bidder total
- Quantity mismatch: any unexplained non-zero difference
- Arithmetic tolerance: larger of `CNY 1` or `0.10%` of the expected line amount
- Stated-total reconciliation tolerance: larger of `CNY 1` or `0.01%` of the stated total

Change a default when project rules, tender documents, price volatility, measurement precision or local regulation justify it. Record the reason.

## Core calculations

For bidder `b`, item `i`, tender quantity `q`, unit price `p`, benchmark `r` and bidder total `T`:

- Expected line amount: `q × p`
- Unit-price deviation: `p / r - 1`
- Price contribution versus benchmark: `(p - r) × q`
- Absolute impact share: `ABS((p - r) × q) / ABS(T)`
- Bidder total gap to control: `bidder total / control total - 1`
- Peer spread: `highest comparable price / lowest comparable price - 1`
- Potential savings for a high-price item: `MAX(0, p - target price) × q`

Never sum percentage deviations. Use amount contributions to explain total differences.

## Abnormal-price categories

- `数据异常`: arithmetic mismatch, OCR uncertainty, missing/duplicate row, unit or quantity mismatch.
- `相对偏高/偏低`: threshold exceeded against a named control or peer benchmark.
- `市场区间外`: comparable price lies above or below the adjusted external range.
- `范围不可比`: specification, tax, freight, installation or date cannot be aligned.

Each flag needs: bidder, item, source value, benchmark, deviation, amount impact, source locator, confidence, explanation and required follow-up.

## Unbalanced pricing

Treat unbalanced pricing as a candidate pattern requiring context. A high or low unit price by itself is insufficient.

Evaluate four dimensions:

1. Price deviation from a comparable reference.
2. Current value contribution to the bid.
3. Exposure to quantity change, design change or measurement uncertainty.
4. Payment timing or front-loading, if the schedule and payment rules are known.

Useful candidate patterns:

- high price on a likely quantity-increase item;
- low price on a likely quantity-decrease item;
- high early-payment items offset by low later-payment items;
- low or zero price that may conceal scope transfer to another item;
- unusually high material component with unusually low installation component, or the reverse, when components are comparable.

If change likelihood or payment timing is unavailable, say so and limit the conclusion to price concentration/deviation.

## Negotiation strategy

Prioritize items by recoverable amount and risk, not by percentage alone.

- For high prices: request cost build-up, supplier quotation, tax/freight basis and scope confirmation; anchor to the strongest comparable benchmark.
- For unusually low prices: confirm no omission, brand/specification, quantity, testing and installation scope; seek a written commitment rather than automatically pressing lower.
- For quantity-sensitive candidates: clarify remeasurement, variation pricing, substitutions and unit-price application.
- For arithmetic or OCR issues: resolve the source fact before commercial negotiation.

For each bidder list: priority, item, evidence, issue, question, requested document, target/reference, potential amount, fallback position and owner/status. Deduplicate overlapping savings opportunities before calculating a total.

## Statistical restraint

- With 2 bidders, show direct ratios and differences only.
- With 3-4 bidders, median and range are useful, but label peer evidence as limited.
- With 5 or more comparable bids, optionally use IQR or median absolute deviation. Keep the formula and cutoff visible.
- A statistical outlier is a review signal, not proof of an invalid or improper bid.
