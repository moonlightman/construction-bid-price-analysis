# Excel report specification

## Audience and structure

The primary audience is the on-site evaluation committee; commercial and cost engineers need the supporting detail. Put decision views first and raw evidence last.

Default sheet order:

1. `评标总览` - project facts, assumptions, bidder ranking, control-price gap, major risks and top negotiation priorities.
2. `总价对比` - stated/reconciled totals, rank, gaps to control/mean/median, spread and reconciliation status.
3. `单价横评` - one row per reviewed BOQ item with bidder unit prices, control price, market range, deviations and amount contributions.
4. `异常报价` - all data, price and market flags with severity, evidence and follow-up.
5. `不平衡报价` - candidate patterns, reference price, deviation contribution, quantity/payment exposure and risk explanation.
6. `市场核价` - external evidence, conversions, adjusted comparable ranges and citations.
7. `谈判策略` - bidder-specific questions, evidence requests, targets, potential savings, fallback and status.
8. `数据校验` - arithmetic checks, quantity/unit mismatches, missing/duplicate items, OCR confidence and unresolved mappings. This is terminal and must not feed business calculations.
9. `原始报价明细` - normalized long-form bidder rows with source locators and original values.
10. `口径与来源` - thresholds, tax/scope basis, mapping rules, source register, limitations and refresh date.

Combine or omit a sheet only when its subject is genuinely absent. Do not create empty decorative tabs.

## Required columns

### 单价横评

`Item key`, `项目名称`, `规格`, `单位`, `招标工程量`, each bidder's `单价` and `合价`, `标底单价`, `市场低/高`, `同行中位数`, bidder deviations, `最大价差`, `差额贡献`, `来源页码`.

### 异常报价

`严重度`, `类别`, `投标人`, `Item key`, `项目`, `来源值`, `基准类型`, `基准值/区间`, `偏差率`, `金额影响`, `事实`, `分析判断`, `需核实`, `建议动作`, `来源定位`, `置信度`, `状态`.

### 不平衡报价

`投标人`, `Item key`, `方向`, `参考类型`, `报价单价`, `参考单价`, `偏差率`, `招标工程量`, `差额贡献`, `占投标总价`, `数量变化暴露`, `付款时点`, `模式`, `证据限制`, `核查问题`.

### 谈判策略

`优先级`, `投标人`, `Item key`, `议题`, `证据`, `现场问题`, `要求材料`, `锚定价/目标区间`, `潜在节省`, `风险`, `备选方案`, `责任人`, `状态`.

## Presentation

- Use a restrained professional palette. Reserve red for high-risk/action-needed, amber for review, green for reconciled/within range and gray for missing/not applicable.
- Freeze headers, enable filters and keep long descriptions wrapped. Use consistent currency and percentage formats.
- Use conditional formatting for deviations and severity, but also keep explicit text labels for accessibility.
- Useful charts: bidder total vs control price, top item amount contributions, unit-price deviation heatmap and negotiation savings by priority. Omit a chart when the data is too sparse or incomparable.
- Avoid merged cells in data tables. Keep the summary compact and trace every headline to a calculation or source table.

## Formula and control design

- Store thresholds once in `口径与来源` and reference them from formulas.
- Keep source amounts as typed numeric values. Derived totals, deviations, ranks and flags should be formulas where practical.
- Separate stated total from reconciled line-item total.
- Preserve missing values as blank/`n.a.`; never convert them to zero with blanket `IFERROR`.
- Use exact item keys for lookups and reject or aggregate duplicates intentionally.
- Keep `数据校验` terminal: outputs and builds must not depend on it.

## Quality assurance

1. Recalculate the workbook.
2. Inspect key summary and detail ranges, including formulas.
3. Scan for `#REF!`, `#DIV/0!`, `#VALUE!`, `#NAME?`, `#N/A`, `#NUM!`, `#NULL!`, `#SPILL!` and `#CALC!`.
4. Independently spot-check bidder totals and several quantity × unit-price rows.
5. Confirm source locators and URLs are present for hardcoded inputs.
6. Render and visually inspect every sheet for clipping, unreadable text, broken charts or `####`.
7. Export one final `.xlsx` file only.
