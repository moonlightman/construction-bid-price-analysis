#!/usr/bin/env python3
"""Validate normalized construction bids and calculate repeatable review signals."""

from __future__ import annotations

import argparse
import json
import math
import statistics
from pathlib import Path
from typing import Any


DEFAULTS = {
    "price_deviation_pct": 0.15,
    "severe_deviation_pct": 0.30,
    "material_impact_share": 0.01,
    "high_impact_share": 0.03,
    "arithmetic_tolerance_abs": 1.0,
    "arithmetic_tolerance_pct": 0.001,
    "total_tolerance_abs": 1.0,
    "total_tolerance_pct": 0.0001,
}


def number(value: Any) -> float | None:
    if value is None or value == "" or isinstance(value, bool):
        return None
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def ratio(value: float | None, reference: float | None) -> float | None:
    if value is None or reference in (None, 0):
        return None
    return value / reference - 1


def tolerance(expected: float, absolute: float, percentage: float) -> float:
    return max(absolute, abs(expected) * percentage)


def severity(
    deviation: float | None, impact_share: float | None, cfg: dict[str, float]
) -> str:
    if (
        impact_share is not None and impact_share >= cfg["high_impact_share"]
    ) or (
        deviation is not None and abs(deviation) >= cfg["severe_deviation_pct"]
    ):
        return "高"
    if (
        impact_share is not None and impact_share >= cfg["material_impact_share"]
    ) or (
        deviation is not None and abs(deviation) >= cfg["price_deviation_pct"]
    ):
        return "中"
    return "低"


def add_flag(flags: list[dict[str, Any]], **record: Any) -> None:
    flags.append(record)


def analyze(data: dict[str, Any]) -> dict[str, Any]:
    project = data.get("project") or {}
    cfg = DEFAULTS.copy()
    for key, value in (project.get("thresholds") or {}).items():
        if key in cfg and number(value) is not None:
            cfg[key] = float(value)

    bidders = data.get("bidders") or []
    items = data.get("items") or []
    bidder_map: dict[str, dict[str, Any]] = {}
    errors: list[str] = []
    warnings: list[str] = []

    for bidder in bidders:
        bidder_id = str(bidder.get("bidder_id") or "").strip()
        if not bidder_id:
            errors.append("Bidder without bidder_id")
        elif bidder_id in bidder_map:
            errors.append(f"Duplicate bidder_id: {bidder_id}")
        else:
            bidder_map[bidder_id] = bidder

    seen_items: set[str] = set()
    line_sums = {bidder_id: 0.0 for bidder_id in bidder_map}
    line_counts = {bidder_id: 0 for bidder_id in bidder_map}
    flags: list[dict[str, Any]] = []
    item_analysis: list[dict[str, Any]] = []
    unbalanced: list[dict[str, Any]] = []
    negotiation: list[dict[str, Any]] = []

    for item in items:
        item_key = str(item.get("item_key") or "").strip()
        if not item_key:
            errors.append("Item without item_key")
            continue
        if item_key in seen_items:
            errors.append(f"Duplicate item_key: {item_key}")
            continue
        seen_items.add(item_key)

        tender_qty = number(item.get("tender_quantity"))
        control = number(item.get("control_unit_price"))
        market_low = number(item.get("market_low"))
        market_high = number(item.get("market_high"))
        if market_low is not None and market_high is not None and market_low > market_high:
            errors.append(f"Item {item_key}: market_low exceeds market_high")

        bid_rows: dict[str, dict[str, Any]] = {}
        comparable_prices: list[float] = []
        for bid in item.get("bids") or []:
            bidder_id = str(bid.get("bidder_id") or "").strip()
            if bidder_id not in bidder_map:
                errors.append(f"Item {item_key}: unknown bidder_id {bidder_id!r}")
                continue
            if bidder_id in bid_rows:
                errors.append(f"Item {item_key}: duplicate bid for bidder {bidder_id}")
                continue
            bid_rows[bidder_id] = bid
            unit_price = number(bid.get("unit_price"))
            if unit_price is not None:
                comparable_prices.append(unit_price)

        peer_median = (
            statistics.median(comparable_prices) if len(comparable_prices) >= 2 else None
        )
        peer_mean = (
            statistics.fmean(comparable_prices) if len(comparable_prices) >= 2 else None
        )

        for bidder_id, bidder in bidder_map.items():
            bid = bid_rows.get(bidder_id)
            if bid is None:
                add_flag(
                    flags,
                    severity="高",
                    category="数据异常",
                    bidder_id=bidder_id,
                    item_key=item_key,
                    issue="缺少报价行",
                    required_follow_up="确认漏项、合并报价或范围排除",
                )
                continue

            unit_price = number(bid.get("unit_price"))
            line_total = number(bid.get("line_total"))
            quoted_qty = number(bid.get("quoted_quantity"))
            calc_qty = quoted_qty if quoted_qty is not None else tender_qty
            stated_total = number(bidder.get("stated_total"))

            if str(bid.get("extraction_confidence") or "").lower() == "low":
                add_flag(
                    flags,
                    severity="高",
                    category="数据异常",
                    bidder_id=bidder_id,
                    item_key=item_key,
                    issue="关键报价字段提取置信度低",
                    required_follow_up="回查原始页并人工确认",
                )

            if line_total is not None:
                line_sums[bidder_id] += line_total
                line_counts[bidder_id] += 1

            if quoted_qty is not None and tender_qty is not None and quoted_qty != tender_qty:
                add_flag(
                    flags,
                    severity="高",
                    category="数据异常",
                    bidder_id=bidder_id,
                    item_key=item_key,
                    issue="投标工程量与招标工程量不一致",
                    source_value=quoted_qty,
                    benchmark=tender_qty,
                    required_follow_up="核对清单版本、计量单位和投标调整说明",
                )

            if unit_price is None or line_total is None or calc_qty is None:
                add_flag(
                    flags,
                    severity="高",
                    category="数据异常",
                    bidder_id=bidder_id,
                    item_key=item_key,
                    issue="数量、单价或合价缺失",
                    required_follow_up="回查原始页并人工确认",
                )
            else:
                expected = calc_qty * unit_price
                diff = line_total - expected
                allowed = tolerance(
                    expected,
                    cfg["arithmetic_tolerance_abs"],
                    cfg["arithmetic_tolerance_pct"],
                )
                if abs(diff) > allowed:
                    add_flag(
                        flags,
                        severity="高",
                        category="数据异常",
                        bidder_id=bidder_id,
                        item_key=item_key,
                        issue="数量乘单价与合价不一致",
                        source_value=line_total,
                        benchmark=expected,
                        amount_impact=diff,
                        required_follow_up="核对舍入、综合单价和原始报价页",
                    )

            preferred_reference = "标底单价" if control is not None else "同行中位数"
            for reference_type, reference in [
                ("标底单价", control),
                ("同行中位数", peer_median),
            ]:
                deviation = ratio(unit_price, reference)
                contribution = (
                    (unit_price - reference) * tender_qty
                    if unit_price is not None
                    and reference is not None
                    and tender_qty is not None
                    else None
                )
                impact_share = (
                    abs(contribution) / abs(stated_total)
                    if contribution is not None and stated_total not in (None, 0)
                    else None
                )
                sev = severity(deviation, impact_share, cfg)
                if deviation is not None and abs(deviation) >= cfg["price_deviation_pct"]:
                    direction = "偏高" if deviation > 0 else "偏低"
                    add_flag(
                        flags,
                        severity=sev,
                        category=f"相对{direction}",
                        bidder_id=bidder_id,
                        item_key=item_key,
                        issue=f"单价相对{reference_type}{direction}",
                        source_value=unit_price,
                        benchmark=reference,
                        benchmark_type=reference_type,
                        deviation_pct=deviation,
                        amount_impact=contribution,
                        impact_share=impact_share,
                        required_follow_up="核实规格、范围和成本构成",
                    )

                if (
                    deviation is not None
                    and contribution is not None
                    and impact_share is not None
                    and abs(deviation) >= cfg["price_deviation_pct"]
                    and impact_share >= cfg["material_impact_share"]
                    and reference_type == preferred_reference
                ):
                    unbalanced.append(
                        {
                            "severity": sev,
                            "bidder_id": bidder_id,
                            "item_key": item_key,
                            "direction": "高" if deviation > 0 else "低",
                            "reference_type": reference_type,
                            "unit_price": unit_price,
                            "reference_price": reference,
                            "deviation_pct": deviation,
                            "difference_contribution": contribution,
                            "impact_share": impact_share,
                            "change_likelihood": number(item.get("change_likelihood")),
                            "payment_stage": item.get("payment_stage"),
                            "limitation": "需结合工程量变更可能性和付款时点判断",
                        }
                    )
                    if deviation > 0:
                        negotiation.append(
                            {
                                "priority": "P1" if sev == "高" else "P2",
                                "bidder_id": bidder_id,
                                "item_key": item_key,
                                "issue": f"单价高于{reference_type}",
                                "target_unit_price": reference,
                                "potential_savings": max(0.0, contribution),
                                "question": "请说明成本构成、税费运费和施工范围，并提供可比报价依据",
                            }
                        )
                    else:
                        negotiation.append(
                            {
                                "priority": "P1" if sev == "高" else "P2",
                                "bidder_id": bidder_id,
                                "item_key": item_key,
                                "issue": f"单价低于{reference_type}",
                                "target_unit_price": None,
                                "potential_savings": 0.0,
                                "question": "请确认无漏项并书面承诺规格、数量、安装测试范围和该单价的适用条件",
                            }
                        )

            market_status = None
            if unit_price is not None and market_low is not None and market_high is not None:
                if unit_price < market_low:
                    market_status = "低于可比市场区间"
                elif unit_price > market_high:
                    market_status = "高于可比市场区间"
                else:
                    market_status = "位于可比市场区间"
                if market_status != "位于可比市场区间":
                    nearest = market_low if unit_price < market_low else market_high
                    deviation = ratio(unit_price, nearest)
                    contribution = (
                        (unit_price - nearest) * tender_qty if tender_qty is not None else None
                    )
                    impact_share = (
                        abs(contribution) / abs(stated_total)
                        if contribution is not None and stated_total not in (None, 0)
                        else None
                    )
                    add_flag(
                        flags,
                        severity=severity(deviation, impact_share, cfg),
                        category="市场区间外",
                        bidder_id=bidder_id,
                        item_key=item_key,
                        issue=market_status,
                        source_value=unit_price,
                        benchmark_low=market_low,
                        benchmark_high=market_high,
                        deviation_pct=deviation,
                        amount_impact=contribution,
                        impact_share=impact_share,
                        required_follow_up="复核市场来源的日期、规格、税费、运费和安装范围",
                    )

            item_analysis.append(
                {
                    "item_key": item_key,
                    "bidder_id": bidder_id,
                    "unit_price": unit_price,
                    "line_total": line_total,
                    "peer_median": peer_median,
                    "peer_mean": peer_mean,
                    "control_unit_price": control,
                    "market_low": market_low,
                    "market_high": market_high,
                    "market_status": market_status,
                    "source_page": bid.get("source_page"),
                    "extraction_confidence": bid.get("extraction_confidence"),
                }
            )

    bidder_summary: list[dict[str, Any]] = []
    control_total = number(project.get("control_total"))
    totals_for_peer = [
        value
        for bidder in bidders
        if (value := number(bidder.get("stated_total"))) is not None
    ]
    peer_total_mean = (
        statistics.fmean(totals_for_peer) if len(totals_for_peer) >= 2 else None
    )
    peer_total_median = (
        statistics.median(totals_for_peer) if len(totals_for_peer) >= 2 else None
    )

    for bidder_id, bidder in bidder_map.items():
        stated_total = number(bidder.get("stated_total"))
        reconciled_total = line_sums[bidder_id] if line_counts[bidder_id] else None
        reconciliation_difference = (
            reconciled_total - stated_total
            if reconciled_total is not None and stated_total is not None
            else None
        )
        reconciliation_status = "无法核对"
        if reconciliation_difference is not None:
            allowed = tolerance(
                stated_total,
                cfg["total_tolerance_abs"],
                cfg["total_tolerance_pct"],
            )
            reconciliation_status = (
                "一致" if abs(reconciliation_difference) <= allowed else "不一致"
            )
            if reconciliation_status == "不一致":
                add_flag(
                    flags,
                    severity="高",
                    category="数据异常",
                    bidder_id=bidder_id,
                    item_key=None,
                    issue="明细汇总与投标总价不一致",
                    source_value=stated_total,
                    benchmark=reconciled_total,
                    amount_impact=reconciliation_difference,
                    required_follow_up="核对未计价项、暂列金、税金、折扣和汇总范围",
                )
        bidder_summary.append(
            {
                "bidder_id": bidder_id,
                "name": bidder.get("name"),
                "stated_total": stated_total,
                "reconciled_total": reconciled_total,
                "reconciliation_difference": reconciliation_difference,
                "reconciliation_status": reconciliation_status,
                "gap_to_control_pct": ratio(stated_total, control_total),
                "gap_to_peer_mean_pct": ratio(stated_total, peer_total_mean),
                "gap_to_peer_median_pct": ratio(stated_total, peer_total_median),
            }
        )

    ranked = sorted(
        (row for row in bidder_summary if row["stated_total"] is not None),
        key=lambda row: row["stated_total"],
    )
    for rank, row in enumerate(ranked, start=1):
        row["rank"] = rank

    flags.sort(
        key=lambda row: (
            {"高": 0, "中": 1, "低": 2}.get(row.get("severity"), 3),
            -abs(number(row.get("amount_impact")) or 0),
        )
    )
    negotiation.sort(
        key=lambda row: (
            row.get("priority", "P9"),
            -(number(row.get("potential_savings")) or 0),
        )
    )

    if len(bidder_map) < 2:
        warnings.append("Fewer than two bidders: peer comparison is unavailable")
    if len(bidder_map) < 5:
        warnings.append(
            "Small bidder sample: treat peer outliers as review signals, not statistical conclusions"
        )
    if control_total is None:
        warnings.append("Missing project control_total")

    return {
        "project": project,
        "thresholds_used": cfg,
        "errors": errors,
        "warnings": warnings,
        "bidder_summary": bidder_summary,
        "item_analysis": item_analysis,
        "anomalies": flags,
        "unbalanced_candidates": unbalanced,
        "negotiation": negotiation,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="Normalized bid JSON")
    parser.add_argument("--output", type=Path, help="Write analysis JSON to this path")
    args = parser.parse_args()

    with args.input.open("r", encoding="utf-8") as stream:
        data = json.load(stream)
    result = analyze(data)
    payload = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(payload + "\n", encoding="utf-8")
    else:
        print(payload)
    return 1 if result["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
